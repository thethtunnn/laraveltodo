<footer>
    <div class="d-flex justify-content-center align-items-center bg-light fixed-bottom" style="height: 60px; z-index: auto;">
        <p class="text-muted small mb-0">&copy; {{ config('app.name', 'Laravel') }} All rights reserved.</span>
    </div> 
</footer>